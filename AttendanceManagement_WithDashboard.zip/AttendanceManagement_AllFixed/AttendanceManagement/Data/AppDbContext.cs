﻿using AttendanceManagement.Models;
using Microsoft.EntityFrameworkCore;

namespace AttendanceManagement.Data
{
    public class AppDbContext : DbContext
    {
        public DbSet<Employee> Employees { get; set; }
        public DbSet<AttendanceRecord> AttendanceRecords { get; set; }
        public DbSet<User> Users { get; set; }
       

        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options) { }

        //public DbSet<Employee> Employees => Set<Employee>();
        //public DbSet<AttendanceRecord> AttendanceRecords => Set<AttendanceRecord>();

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AttendanceRecord>()
                .HasIndex(a => new { a.EmployeeId, a.Date })
                .IsUnique();

            base.OnModelCreating(modelBuilder);
        }
    }

}
