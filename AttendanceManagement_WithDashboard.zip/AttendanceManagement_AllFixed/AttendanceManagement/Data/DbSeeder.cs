using System;
using System.Linq;
using AttendanceManagement.Models;
using Microsoft.EntityFrameworkCore;

namespace AttendanceManagement.Data
{
    public static class DbSeeder
    {
        public static void Seed(AppDbContext db)
        {
            db.Database.Migrate();

            if (!db.Employees.Any())
            {
                db.Employees.AddRange(
                    new Employee { Name = "Amit Sharma", Email = "amit.sharma@example.in", Department = "HR", JoinDate = new DateTime(2022,1,15) },
                    new Employee { Name = "Neha Gupta", Email = "neha.gupta@example.in", Department = "IT", JoinDate = new DateTime(2021,6,20) },
                    new Employee { Name = "Ravi Kumar", Email = "ravi.kumar@example.in", Department = "Finance", JoinDate = new DateTime(2023,3,10) },
                    new Employee { Name = "Priya Singh", Email = "priya.singh@example.in", Department = "IT", JoinDate = new DateTime(2022,11,5) },
                    new Employee { Name = "Suresh Patel", Email = "suresh.patel@example.in", Department = "Marketing", JoinDate = new DateTime(2021,9,30) }
                );
                db.SaveChanges();
            }
        }
    }
}
