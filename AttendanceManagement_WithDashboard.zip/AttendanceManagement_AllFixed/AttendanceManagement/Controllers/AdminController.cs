﻿using AttendanceManagement.Data;
using AttendanceManagement.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using AttendanceManagement.Models.ViewModels; 

namespace AttendanceManagement.Controllers
{
    public class AdminController : Controller
    {
        private readonly AppDbContext _context;

        public AdminController(AppDbContext context)
        {
            _context = context;
        }


        public async Task<IActionResult> Dashboard(DateTime? from, DateTime? to)
        {
            var employees = await _context.Employees.ToListAsync();

            var startDate = from ?? DateTime.Today;
            var endDate = to ?? DateTime.Today;

            var attendanceRecords = await _context.AttendanceRecords
                .Include(a => a.Employee)
                .Where(a => a.Date >= startDate && a.Date <= endDate)
                .ToListAsync();

            int before9 = 0, before915 = 0, after915 = 0, after930 = 0, onLeave = 0, absent = 0;

            foreach (var emp in employees)
            {
                var record = attendanceRecords
                    .Where(a => a.EmployeeId == emp.Id)
                    .OrderByDescending(a => a.Date)
                    .FirstOrDefault();

                if (record == null)
                {
                    absent++;
                    continue;
                }

                if (record.Status == "Leave")
                {
                    onLeave++;
                }
                else if (record.CheckInTime.HasValue)
                {
                    var time = record.CheckInTime.Value.TimeOfDay;

                    if (time < new TimeSpan(9, 0, 0))
                        before9++;
                    else if (time < new TimeSpan(9, 15, 0))
                        before915++;
                    else if (time < new TimeSpan(9, 30, 0))
                        after915++;
                    else
                        after930++;
                }
                else
                {
                    after930++;
                }
            }

            var chartData = new List<AttendanceChartViewModel>
    {
        new AttendanceChartViewModel { Status = "Before 9 am", Count = before9 },
        new AttendanceChartViewModel { Status = "Before 9:15 am", Count = before915 },
        new AttendanceChartViewModel { Status = "After 9:15 am", Count = after915 },
        new AttendanceChartViewModel { Status = "After 9:30 am", Count = after930 },
        new AttendanceChartViewModel { Status = "On Leave", Count = onLeave },
        new AttendanceChartViewModel { Status = "Absent", Count = absent }
    };

            ViewBag.StatusChartData = chartData;
            ViewBag.From = startDate.ToString("yyyy-MM-dd");
            ViewBag.To = endDate.ToString("yyyy-MM-dd");

            return View(employees);
        }



        // GET: /Admin/Attendance
        public async Task<IActionResult> Attendance(DateTime? from, DateTime? to, int? employeeId)
        {
            var query = _context.AttendanceRecords
                .Include(a => a.Employee)
                .AsQueryable();

            if (from.HasValue)
                query = query.Where(a => a.Date >= from.Value.Date);
            if (to.HasValue)
                query = query.Where(a => a.Date <= to.Value.Date);
            if (employeeId.HasValue && employeeId.Value > 0)
                query = query.Where(a => a.EmployeeId == employeeId.Value);

            var records = await query
                .OrderByDescending(a => a.Date)
                .ThenBy(a => a.Employee.Name)
                .ToListAsync();

            ViewBag.Employees = await _context.Employees
                .OrderBy(e => e.Name)
                .ToListAsync();

            return View(records);
        }     
    }
}
