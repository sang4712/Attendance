﻿using AttendanceManagement.Data;
using AttendanceManagement.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AttendanceManagement.Controllers
{
    //[Authorize]
    public class AttendanceController : Controller
    {
        private readonly AppDbContext _context;

        public AttendanceController(AppDbContext context)
        {
            _context = context;
        }
        public async Task<IActionResult> Mark(int? employeeId)
        {
            // Load all employees for dropdown
            var employees = await _context.Employees.ToListAsync();
            ViewBag.Employees = employees;
            ViewBag.EmployeeId = employeeId;

            AttendanceRecord? record = null;

            if (employeeId.HasValue)
            {
                var today = DateTime.Today;
                record = await _context.AttendanceRecords
                    .Include(a => a.Employee)
                    .FirstOrDefaultAsync(a => a.EmployeeId == employeeId.Value && a.Date == today);
            }

            ViewBag.Record = record;
            return View();
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SaveManualAttendance(DateTime Date, string? CheckInTime, string? CheckOutTime)
        {
            var employeeId = GetLoggedInEmployeeId();

            if (employeeId == 0)
            {
                TempData["Message"] = "⚠️ Please login first before marking attendance.";
                return RedirectToAction("Index", "Login");
            }

            var today = DateTime.Today;

            // Prevent backdated check-in
            if (!string.IsNullOrEmpty(CheckInTime) && Date < today)
            {
                TempData["Message"] = "Backdated check-in is not allowed.";
                return RedirectToAction(nameof(Index));
            }

            // Prevent out-of-bound check-out date
            if (!string.IsNullOrEmpty(CheckOutTime) && (Date < today.AddDays(-1) || Date > today))
            {
                TempData["Message"] = "Check-out can only be applied for today or yesterday.";
                return RedirectToAction(nameof(Index));
            }

            var record = await _context.AttendanceRecords
                .FirstOrDefaultAsync(a => a.EmployeeId == employeeId && a.Date == Date);

            bool isFirstPunch = false;
            if (record == null)
            {
                record = new AttendanceRecord
                {
                    EmployeeId = employeeId,
                    Date = Date
                };
                _context.AttendanceRecords.Add(record);
                isFirstPunch = true;
            }
            else
            {
                isFirstPunch = (record.CheckInTime == null && record.CheckOutTime == null);
            }

            // If it's the first punch and only CheckOut is entered, treat it as CheckIn
            if (isFirstPunch && string.IsNullOrEmpty(CheckInTime) && !string.IsNullOrEmpty(CheckOutTime))
            {
                CheckInTime = CheckOutTime;
                CheckOutTime = null;
                record.IsAutoCheckIn = true; // Mark as auto-check-in
            }

            // Only allow manual update if it's not an auto-check-in
            if (!string.IsNullOrEmpty(CheckInTime))
            {
                if (record.IsAutoCheckIn)
                {
                    TempData["Message"] = "You cannot change an automatically assigned Check-In. Please contact admin.";
                    return RedirectToAction(nameof(Index));
                }
                else
                {
                    record.CheckInTime = Date.Date + TimeSpan.Parse(CheckInTime);
                    record.IsAutoCheckIn = false; // Since user updated it manually
                }
            }

            if (!string.IsNullOrEmpty(CheckOutTime))
            {
                record.CheckOutTime = Date.Date + TimeSpan.Parse(CheckOutTime);
            }

            // Now set the status based on Check-In and Check-Out times:
            if (record.CheckInTime == null && record.CheckOutTime == null)
            {
                record.Status = "Absent";
            }
            else if (record.CheckInTime == null && record.CheckOutTime != null)
            {
                // First punch with no check-in, auto-assign check-in if not already done
                if (!record.IsAutoCheckIn)
                {
                    record.CheckInTime = record.CheckOutTime;
                    record.IsAutoCheckIn = true;
                }
                record.Status = "Present (auto check-in)"; // You could shorten this if needed
            }
            else if (record.CheckInTime != null && record.CheckOutTime == null)
            {
                record.Status = "Checked In - No Check-Out";  // Shorten if column size is too small
            }
            else
            {
                // Normal case where both Check-In and Check-Out exist
                if (record.CheckInTime.Value.TimeOfDay > new TimeSpan(9, 30, 0))
                    record.Status = "Late";
                else
                    record.Status = "Present";
            }


            await _context.SaveChangesAsync();
            TempData["Message"] = "Attendance updated successfully.";
            return RedirectToAction(nameof(Index));
        }



        // Simulate logged-in employee ID(replace this with actual login system later)
        //private int GetLoggedInEmployeeId()
        //{
        //    return 1; // Hardcode for now
        //}
        private int GetLoggedInEmployeeId()
        {
            var employeeIdClaim = User.Claims.FirstOrDefault(c => c.Type == "EmployeeId")?.Value;
            return employeeIdClaim != null ? int.Parse(employeeIdClaim) : 0;
        }

        public async Task<IActionResult> Index()
        {
            var employeeId = GetLoggedInEmployeeId();
            var today = DateTime.Today;

            var record = await _context.AttendanceRecords
                .Include(a => a.Employee)
                .FirstOrDefaultAsync(a => a.EmployeeId == employeeId && a.Date == today);

            ViewBag.Employee = await _context.Employees.FindAsync(employeeId);
            ViewBag.Record = record;

            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CheckIn()
        {
            var employeeId = GetLoggedInEmployeeId();

            if (employeeId == 0)
            {
                TempData["Message"] = "⚠️ Please login first.";
                return RedirectToAction("Index", "Login");
            }
            var today = DateTime.Today;

            var record = await _context.AttendanceRecords
                .FirstOrDefaultAsync(a => a.EmployeeId == employeeId && a.Date == today);

            if (record != null && record.CheckInTime != null)
            {
                TempData["Message"] = "Already checked in today.";
                return RedirectToAction(nameof(Index));
            }

            if (record == null)
            {
                record = new AttendanceRecord
                {
                    EmployeeId = employeeId,
                    Date = today
                };
                _context.AttendanceRecords.Add(record);
            }

            record.CheckInTime = DateTime.Now;
            record.Status = DateTime.Now.TimeOfDay > new TimeSpan(9, 30, 0) ? "Late" : "Present";

            await _context.SaveChangesAsync();
            TempData["Message"] = "Checked in successfully.";
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CheckOut()
        {
            var employeeId = GetLoggedInEmployeeId();

            if (employeeId == 0)
            {
                TempData["Message"] = "⚠️ Please login first.";
                return RedirectToAction("Index", "Login");
            }
            var today = DateTime.Today;

            var record = await _context.AttendanceRecords
                .FirstOrDefaultAsync(a => a.EmployeeId == employeeId && a.Date == today);

            if (record == null)
            {
                TempData["Message"] = "No check-in record found for today.";
                return RedirectToAction(nameof(Index));
            }

            if (record.CheckOutTime != null)
            {
                TempData["Message"] = "Already checked out today.";
                return RedirectToAction(nameof(Index));
            }

            record.CheckOutTime = DateTime.Now;
            await _context.SaveChangesAsync();

            TempData["Message"] = "Checked out successfully.";
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        public async Task<IActionResult> EditAttendance(int id, DateTime? checkInTime, DateTime? checkOutTime, string status)
        {
            var record = await _context.AttendanceRecords.FindAsync(id);
            if (record == null)
            {
                return NotFound();
            }

            record.CheckInTime = checkInTime;
            record.CheckOutTime = checkOutTime;
            record.Status = status;

            _context.Update(record);
            await _context.SaveChangesAsync();

            // Redirect back to Admin/Attendance
            return RedirectToAction("Attendance", "Admin");
        }

    }
}
