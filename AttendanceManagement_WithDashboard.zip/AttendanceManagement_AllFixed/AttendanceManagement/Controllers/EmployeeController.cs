using AttendanceManagement.Data;
using AttendanceManagement.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace AttendanceManagement.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly AppDbContext _context;
        public EmployeeController(AppDbContext context)
        {
            _context = context;
        }

        // List
        public async Task<IActionResult> Index()
        {
            var employees = await _context.Employees.ToListAsync();
            return View(employees);
        }

        // Create GET
        public IActionResult Create()
        {
            return View(new EmployeeUserViewModel());
        }

        // Create POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(EmployeeUserViewModel vm)
        {
            if (!ModelState.IsValid) return View(vm);

            if (await _context.Employees.AnyAsync(e => e.Email == vm.Email))
            {
                ModelState.AddModelError("Email", "Email already exists.");
                return View(vm);
            }
            if (await _context.Users.AnyAsync(u => u.Username == vm.Username))
            {
                ModelState.AddModelError("Username", "Username already exists.");
                return View(vm);
            }

            var employee = new Employee
            {
                Name = vm.Name,
                Email = vm.Email,
                Department = vm.Department,
                JoinDate = vm.JoinDate
            };
            _context.Employees.Add(employee);
            await _context.SaveChangesAsync();

            using var sha = SHA256.Create();
            var hashBytes = sha.ComputeHash(Encoding.UTF8.GetBytes(vm.Password ?? ""));
            var hash = BitConverter.ToString(hashBytes).Replace("-", "").ToLower();

            var user = new User
            {
                Username = vm.Username,
                PasswordHash = hash,
                PasswordPlain = vm.Password ?? "",
                Role = vm.Role,
                EmployeeId = employee.Id
            };
            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            TempData["Message"] = "Employee & User created successfully.";
            return RedirectToAction(nameof(Index));
        }

        // Edit GET
        // GET: Employee/Edit/6
        public async Task<IActionResult> Edit(int id)
        {
            var employee = await _context.Employees.FindAsync(id);
            if (employee == null)
                return NotFound();

            var user = await _context.Users.FirstOrDefaultAsync(u => u.EmployeeId == id);

            var vm = new EmployeeUserViewModel
            {
                EmployeeId = employee.Id,
                Name = employee.Name,
                Email = employee.Email,
                Department = employee.Department,
                JoinDate = employee.JoinDate,
                UserId = user?.UserId ?? 0,
                Username = user?.Username,
                Role = user?.Role
            };

            return View(vm);
        }


        // Edit POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(EmployeeUserViewModel vm)
        {
            if (!ModelState.IsValid) return View(vm);

            var employee = await _context.Employees.FindAsync(vm.EmployeeId);
            if (employee == null) return NotFound();

            // Update employee
            employee.Name = vm.Name;
            employee.Email = vm.Email;
            employee.Department = vm.Department;
            employee.JoinDate = vm.JoinDate;

            // Find existing user or create new
            var user = await _context.Users.FirstOrDefaultAsync(u => u.EmployeeId == vm.EmployeeId);
            if (user == null)
            {
                user = new User
                {
                    EmployeeId = employee.Id
                };
                _context.Users.Add(user); // add new user if missing
            }

            // Update user info
            user.Username = vm.Username;
            user.Role = vm.Role;

            // Update password only if entered
            if (!string.IsNullOrWhiteSpace(vm.Password))
            {
                using var sha = SHA256.Create();
                var hashBytes = sha.ComputeHash(Encoding.UTF8.GetBytes(vm.Password));
                user.PasswordHash = BitConverter.ToString(hashBytes).Replace("-", "").ToLower();
                user.PasswordPlain = vm.Password;
            }

            await _context.SaveChangesAsync();
            TempData["Message"] = "Employee & User updated successfully.";
            return RedirectToAction(nameof(Index));
        }

        // Delete GET
        public async Task<IActionResult> Delete(int id)
        {
            var employee = await _context.Employees.FindAsync(id);
            if (employee == null) return NotFound();
            return View(employee);
        }

        // Delete POST
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var employee = await _context.Employees.FindAsync(id);
            if (employee != null)
            {
                _context.Employees.Remove(employee);
                var user = await _context.Users.FirstOrDefaultAsync(u => u.EmployeeId == id);
                if (user != null) _context.Users.Remove(user);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }
    }
}
