
using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using AttendanceManagement.Data;
using AttendanceManagement.Models;
using AttendanceManagement.Models.ViewModels;

namespace AttendanceManagement.Controllers
{
    [Authorize]
    public class DashboardController : Controller
    {
        private readonly AppDbContext _context;
        private static readonly TimeSpan LateThreshold = new TimeSpan(9, 30, 0); // 9:30 AM

        public DashboardController(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            var today = DateTime.Today;

            // Total employees
            var totalEmployees = await _context.Employees.CountAsync();

            // Present today (with a record that has CheckInTime)
            var presentToday = await _context.AttendanceRecords
                .Where(a => a.Date == today && a.CheckInTime != null)
                .Select(a => a.EmployeeId)
                .Distinct()
                .CountAsync();

            // Absent = total - present (simple heuristic)
            var absentToday = Math.Max(0, totalEmployees - presentToday);

            // Late = checkin after threshold
            var lateToday = await _context.AttendanceRecords
                .Where(a => a.Date == today && a.CheckInTime != null)
                .CountAsync(a => a.CheckInTime!.Value.TimeOfDay > LateThreshold);

            // Average working hours over last 7 days for completed records
            var fromDate = today.AddDays(-6);
            var rec7 = await _context.AttendanceRecords
                .Where(a => a.Date >= fromDate && a.Date <= today && a.CheckInTime != null && a.CheckOutTime != null)
                .ToListAsync();

            double avgHours7 = 0;
            if (rec7.Count > 0)
            {
                avgHours7 = rec7.Average(r => (r.CheckOutTime!.Value - r.CheckInTime!.Value).TotalHours);
            }

            // Last 7 days presents (distinct employees who checked in per day)
            var last7Labels = Enumerable.Range(0, 7).Select(i => fromDate.AddDays(i)).ToList();
            var last7Presents = new System.Collections.Generic.List<int>();
            foreach (var d in last7Labels)
            {
                var count = await _context.AttendanceRecords
                    .Where(a => a.Date == d && a.CheckInTime != null)
                    .Select(a => a.EmployeeId)
                    .Distinct()
                    .CountAsync();
                last7Presents.Add(count);
            }

            // Monthly presents in last 12 months
            var startMonth = new DateTime(today.Year, today.Month, 1).AddMonths(-11);
            var monthLabels = new System.Collections.Generic.List<string>();
            var monthValues = new System.Collections.Generic.List<int>();

            for (int i = 0; i < 12; i++)
            {
                var monthStart = new DateTime(startMonth.Year, startMonth.Month, 1).AddMonths(i);
                var monthEnd = monthStart.AddMonths(1).AddDays(-1);
                var count = await _context.AttendanceRecords
                    .Where(a => a.Date >= monthStart && a.Date <= monthEnd && a.CheckInTime != null)
                    .CountAsync();
                monthLabels.Add(monthStart.ToString("MMM yyyy"));
                monthValues.Add(count);
            }

            // Recent 10 check-ins
            var recent = await _context.AttendanceRecords
                .Where(a => a.CheckInTime != null)
                .OrderByDescending(a => a.CheckInTime)
                .Include(a => a.Employee)
                .Take(10)
                .ToListAsync();

            var vm = new DashboardViewModel
            {
                TotalEmployees = totalEmployees,
                PresentToday = presentToday,
                AbsentToday = absentToday,
                LateToday = lateToday,
                AvgHours7Days = Math.Round(avgHours7, 2),
                Last7DaysLabels = last7Labels.Select(d => d.ToString("dd MMM")).ToList(),
                Last7DaysPresents = last7Presents,
                MonthLabels = monthLabels,
                MonthlyPresents = monthValues,
                RecentCheckIns = recent
            };

            return View(vm);
        }
    }
}
