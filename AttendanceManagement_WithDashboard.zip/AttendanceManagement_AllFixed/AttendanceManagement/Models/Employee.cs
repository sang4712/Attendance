﻿using System.ComponentModel.DataAnnotations;

namespace AttendanceManagement.Models
{
    public class Employee
    {
        public int Id { get; set; }

        [Required, StringLength(100)]
        public string Name { get; set; } = null!;

        [Required, EmailAddress]
        public string Email { get; set; } = null!;

        public string? Department { get; set; }

        [DataType(DataType.Date)]
        public DateTime JoinDate { get; set; }
        //ublic string Role { get; set; } = "Employee";
    }
}
