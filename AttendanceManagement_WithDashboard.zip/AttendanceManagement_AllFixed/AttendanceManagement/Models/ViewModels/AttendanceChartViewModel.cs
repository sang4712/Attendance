﻿namespace AttendanceManagement.Models.ViewModels
{
    public class AttendanceChartViewModel
    {
        public string Status { get; set; }
        public int Count { get; set; }
        public string Tooltip { get; set; }
    }
}