
using System;
using System.Collections.Generic;
using AttendanceManagement.Models;

namespace AttendanceManagement.Models.ViewModels
{
    public class DashboardViewModel
    {
        // KPIs
        public int TotalEmployees { get; set; }
        public int PresentToday { get; set; }
        public int AbsentToday { get; set; }
        public int LateToday { get; set; }
        public double AvgHours7Days { get; set; }

        // Charts
        public List<string> MonthLabels { get; set; } = new();
        public List<int> MonthlyPresents { get; set; } = new();

        public List<string> Last7DaysLabels { get; set; } = new();
        public List<int> Last7DaysPresents { get; set; } = new();

        // Recent activity
        public List<AttendanceRecord> RecentCheckIns { get; set; } = new();
    }
}
