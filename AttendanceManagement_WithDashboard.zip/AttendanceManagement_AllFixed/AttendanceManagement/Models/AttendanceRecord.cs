﻿using System.ComponentModel.DataAnnotations;

namespace AttendanceManagement.Models
{
    public class AttendanceRecord
    {
        public int Id { get; set; }
        public int EmployeeId { get; set; }

        [DataType(DataType.Date)]
        public DateTime Date { get; set; }

        [DataType(DataType.Time)]
        public DateTime? CheckInTime { get; set; }

        [DataType(DataType.Time)]
        public DateTime? CheckOutTime { get; set; }

        public string Status { get; set; } = "Present";

        public Employee? Employee { get; set; }

        public bool IsAutoCheckIn { get; set; } = false;

    }
}
