using System;
using System.ComponentModel.DataAnnotations;

namespace AttendanceManagement.Models
{
    public class EmployeeUserViewModel
    {
        public int EmployeeId { get; set; }
        [Required, StringLength(100)]
        public string Name { get; set; } = string.Empty;
        [Required, EmailAddress]
        public string Email { get; set; } = string.Empty;
        public string? Department { get; set; }
        [DataType(DataType.Date)]
        public DateTime JoinDate { get; set; }

        public int UserId { get; set; }
        [Required]
        public string Username { get; set; } = string.Empty;
        [DataType(DataType.Password)]
        public string? Password { get; set; }
        public string Role { get; set; } = "Employee";
    }
}
